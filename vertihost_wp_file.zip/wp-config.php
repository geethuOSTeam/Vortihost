<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'vortihost_wp_l8irl' );

/** Database username */
define( 'DB_USER', 'vortihost_wp_simrm' );

/** Database password */
define( 'DB_PASSWORD', '4&FT7u*L!6Md0aqz' );

/** Database hostname */
define( 'DB_HOST', 'localhost:3306' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY', '29i__(:&9AoeRIap8N7jhX(JutRL]f3Dx_oVlc@:3D/Q(7X#2R~O~FF&@0iE4ecS');
define('SECURE_AUTH_KEY', 'K188c%|9b5@~J-eU44@S@&(K95(#yiYX65e7o%a[W5&OpZQ2#i9Wu7C;Il3W+j42');
define('LOGGED_IN_KEY', '9K63-QWD3L*]3pn[WMJNa%m)9d5zl44+wj3!S@G6MuwPnBu]qJX#Jmbf40xc*20k');
define('NONCE_KEY', '!J~2f:TZi0~p[!3LQa8BP(P(OmC@j7f+!:YLw+5%1Y620fRg!3mF_/zke/E/7xfO');
define('AUTH_SALT', '-Sa1D/5@43+50v4A#zbuED*(V]l4(:~1KB/2b(zy6n7h/#IXWV@x[8*DSfk9Nz61');
define('SECURE_AUTH_SALT', '2;X)%60~ji[[oE0r1bvO%6b@2J5OWVSbSrZ#)728:831baQI40j@2x1r;mlF/C2C');
define('LOGGED_IN_SALT', '_Y-&85o6U3y%W!%c7+Kg9BLU2t162t[:&NeW626tJVM!07|2GLF(Ki]U:37f4sb7');
define('NONCE_SALT', '1Y4@SvnD+H1VK70q6SY~ti&G)%I%xg7+:)4N9K32b)ln8mHcY*tjB(rnFUVis#A5');


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'mZAMvdL_';


/* Add any custom values between this line and the "stop editing" line. */

define('WP_ALLOW_MULTISITE', true);
/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
